# Placement Prediction and Model Comparison System

**Wipro CPPE – Module 3: AI Engineering – Use Case 10**

This project implements the use case described in the Wipro CPPE AI Engineering handout: develop machine-learning models to predict student placement outcomes and compare algorithms using accuracy, precision, recall, F1-score, and related metrics.

> **Important:** The bundled dataset is synthetic and generated for educational demonstration. It is not real student data and does not provide a valid estimate of actual placement outcomes. Do not use it to make recruitment, admission, or career decisions.

## Features

- Streamlit web dashboard
- Synthetic student placement dataset (1,200 records)
- Dataset preview, class distribution, and CSV download
- Data validation and median imputation pipeline
- Four models: Logistic Regression, Decision Tree, Random Forest, Gradient Boosting
- Test-set evaluation: accuracy, precision, recall, F1-score, ROC-AUC
- Model comparison chart and downloadable results
- Interactive demonstration prediction for a sample student profile
- Reproducible train/test split with a fixed random seed

## Project structure

```text
wipro_placement_prediction_model_comparison/
├── app.py
├── model_pipeline.py
├── requirements.txt
├── README.md
├── .gitignore
└── data/
    └── student_placement_demo.csv
```

## Requirements

- Python 3.10 or newer recommended
- pip
- VS Code or another Python editor

## Run locally

### Windows

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL shown in the terminal, normally `http://localhost:8501`.

## Dataset columns

| Column | Description |
|---|---|
| `cgpa` | Synthetic CGPA |
| `aptitude_score` | Synthetic aptitude assessment score (0–100) |
| `coding_score` | Synthetic coding score (0–100) |
| `communication_score` | Synthetic communication score (0–100) |
| `projects` | Synthetic number of projects |
| `internships` | Synthetic number of internships |
| `certifications` | Synthetic number of certifications |
| `placed` | Synthetic target: 1 = Placed, 0 = Not Placed |

## Model evaluation

The dashboard trains all four algorithms on 75% of the dataset and evaluates them on the remaining 25%. Metrics are calculated when the comparison page is opened; they are not hard-coded.

Because the dataset is synthetic and its labels are generated from a simulated rule, high evaluation scores would not demonstrate real-world predictive ability.

## Push to GitHub

1. Create an empty repository on GitHub.
2. Extract this ZIP.
3. Open a terminal in the extracted project directory.
4. Run the following commands, replacing the example remote with your own repository URL:

```bash
git init
git add .
git commit -m "Add placement prediction and model comparison system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Do not commit private student records, credentials, API keys, or environment files.

## Suggested placement explanation

"My project implements the Wipro CPPE AI Engineering use case for Placement Prediction and Model Comparison. It uses a synthetic student dataset and compares Logistic Regression, Decision Tree, Random Forest, and Gradient Boosting. I evaluate the models using accuracy, precision, recall, F1-score, and ROC-AUC on a held-out test set. The Streamlit dashboard lets a reviewer inspect the dataset, compare model metrics, and test a sample profile. The dataset is synthetic, so the results are for learning and demonstration only."

## Future enhancements

- Replace synthetic data with an authorized, anonymized dataset.
- Add cross-validation and confusion matrices.
- Add feature importance and explainability.
- Add data drift and fairness checks.
- Deploy to a cloud platform with appropriate privacy and access controls.

## License

For learning and placement demonstration. Add a license if you intend to publish under a particular open-source license.

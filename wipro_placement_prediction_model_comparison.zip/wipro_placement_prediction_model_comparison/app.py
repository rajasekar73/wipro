import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from model_pipeline import load_dataset, train_and_compare, predict_placement

ROOT = Path(__file__).parent
DATA_PATH = ROOT / "data" / "student_placement_demo.csv"

st.set_page_config(page_title="Placement Prediction & Model Comparison", page_icon="🎓", layout="wide")

st.title("🎓 Placement Prediction and Model Comparison System")
st.caption("Wipro CPPE • Module 3 – AI Engineering • Use Case 10")

st.warning(
    "Educational demonstration only. The included dataset is synthetic and the model is not validated "
    "for real hiring decisions. Do not use the results to make actual recruitment or career decisions."
)

data = load_dataset(DATA_PATH)

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Select a page", [
        "Overview", "Explore Dataset", "Train & Compare Models", "Predict Demo Outcome"
    ])
    st.markdown("---")
    st.write("**Use case:** Develop ML models to predict student placement outcomes and compare algorithms.")

if page == "Overview":
    st.subheader("Project overview")
    a, b, c = st.columns(3)
    a.metric("Demo records", f"{len(data):,}")
    b.metric("Input features", "7")
    c.metric("Target classes", "Placed / Not Placed")
    st.markdown("""
    ### Workflow
    1. Load a student placement dataset.
    2. Inspect and preprocess numeric and categorical features.
    3. Split data into training and testing subsets.
    4. Train Logistic Regression, Decision Tree, Random Forest, and Gradient Boosting models.
    5. Compare Accuracy, Precision, Recall, F1-score, and ROC-AUC where available.
    6. Use a selected model to generate a demonstration prediction for a sample student profile.
    """)
    st.info("The demo dataset is generated for this repository. Replace it with an authorized, appropriately anonymized dataset for further experiments.")

elif page == "Explore Dataset":
    st.subheader("Student placement demo dataset")
    st.write("The included records are synthetic—not real student records.")
    st.dataframe(data.head(50), use_container_width=True)
    x, y, z = st.columns(3)
    x.metric("Rows", len(data))
    y.metric("Columns", len(data.columns))
    z.metric("Missing values", int(data.isna().sum().sum()))
    st.download_button(
        "Download dataset CSV",
        data=data.to_csv(index=False).encode("utf-8"),
        file_name="student_placement_demo.csv",
        mime="text/csv"
    )
    st.subheader("Placement outcome distribution")
    counts = data["placed"].map({1: "Placed", 0: "Not Placed"}).value_counts()
    fig, ax = plt.subplots()
    counts.plot(kind="bar", ax=ax)
    ax.set_xlabel("Outcome")
    ax.set_ylabel("Number of students")
    ax.set_title("Synthetic dataset class distribution")
    st.pyplot(fig)
    plt.close(fig)

elif page == "Train & Compare Models":
    st.subheader("Train and compare machine-learning models")
    with st.spinner("Training models and evaluating on a held-out test set..."):
        results, trained, split = train_and_compare(data)
    st.caption(f"Train records: {split['train_rows']} • Test records: {split['test_rows']} • Random state: 42")
    st.dataframe(results.sort_values("F1-score", ascending=False).reset_index(drop=True), use_container_width=True)
    st.markdown("**Metric notes:** Precision measures how many predicted positive cases were positive; recall measures how many actual positive cases were found; F1-score balances precision and recall.")
    fig, ax = plt.subplots()
    plot_df = results.set_index("Model")[["Accuracy", "Precision", "Recall", "F1-score"]]
    plot_df.plot(kind="bar", ax=ax)
    ax.set_ylim(0, 1)
    ax.set_ylabel("Score")
    ax.set_title("Model metric comparison (synthetic data)")
    ax.legend(loc="lower right")
    plt.xticks(rotation=15, ha="right")
    st.pyplot(fig)
    plt.close(fig)
    st.download_button(
        "Download model comparison CSV",
        data=results.to_csv(index=False).encode("utf-8"),
        file_name="model_comparison_results.csv",
        mime="text/csv"
    )
    st.success("Metrics are calculated when this page is opened. They are not hard-coded.")
    st.warning("Because the dataset is synthetic and rule-generated, these scores are not evidence of real-world placement prediction performance.")

elif page == "Predict Demo Outcome":
    st.subheader("Try a synthetic student profile")
    st.write("These inputs are for a demonstration only; they should not be used to evaluate real students.")
    c1, c2 = st.columns(2)
    with c1:
        cgpa = st.slider("CGPA", 4.0, 10.0, 7.5, 0.1)
        aptitude = st.slider("Aptitude score (0–100)", 0, 100, 70)
        coding = st.slider("Coding score (0–100)", 0, 100, 65)
        communication = st.slider("Communication score (0–100)", 0, 100, 70)
    with c2:
        projects = st.slider("Completed projects", 0, 8, 2)
        internships = st.slider("Internships completed", 0, 4, 1)
        certifications = st.slider("Relevant certifications", 0, 10, 2)
        model_name = st.selectbox("Model", [
            "Random Forest", "Logistic Regression", "Decision Tree", "Gradient Boosting"
        ])
    if st.button("Predict demo outcome", type="primary"):
        profile = {
            "cgpa": cgpa, "aptitude_score": aptitude, "coding_score": coding,
            "communication_score": communication, "projects": projects,
            "internships": internships, "certifications": certifications
        }
        result = predict_placement(data, profile, model_name)
        st.metric("Demo model output", result["label"])
        st.metric("Model estimated probability of 'Placed'", f"{result['probability']:.1%}")
        st.caption(f"Model used: {model_name}")
        st.json(profile)
        st.info("This is a model output from synthetic data, not a reliable estimate of an actual person's employment prospects.")

st.markdown("---")
st.caption("Wipro CPPE AI Engineering use case 10 • Built with Python, pandas, scikit-learn, Streamlit.")

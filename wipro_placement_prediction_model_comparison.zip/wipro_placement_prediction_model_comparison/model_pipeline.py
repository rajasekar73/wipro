import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

FEATURES = [
    "cgpa", "aptitude_score", "coding_score", "communication_score",
    "projects", "internships", "certifications"
]
TARGET = "placed"

def generate_demo_dataset(n=1200, seed=42):
    """Generate artificial student records; not real student data."""
    rng = np.random.default_rng(seed)
    cgpa = np.clip(rng.normal(7.2, 1.0, n), 4.0, 10.0)
    aptitude = np.clip(rng.normal(62, 18, n), 0, 100)
    coding = np.clip(rng.normal(60, 20, n), 0, 100)
    communication = np.clip(rng.normal(65, 17, n), 0, 100)
    projects = rng.integers(0, 7, n)
    internships = rng.integers(0, 4, n)
    certifications = rng.integers(0, 9, n)

    # Synthetic target-generation rule with noise; this is not a real hiring model.
    score = (
        0.65 * (cgpa - 6.5) + 0.018 * (aptitude - 50) +
        0.022 * (coding - 50) + 0.012 * (communication - 50) +
        0.18 * projects + 0.28 * internships + 0.07 * certifications +
        rng.normal(0, 1.15, n)
    )
    probability = 1 / (1 + np.exp(-score))
    placed = rng.binomial(1, probability)
    return pd.DataFrame({
        "cgpa": cgpa.round(2),
        "aptitude_score": aptitude.round(1),
        "coding_score": coding.round(1),
        "communication_score": communication.round(1),
        "projects": projects,
        "internships": internships,
        "certifications": certifications,
        "placed": placed
    })

def load_dataset(path):
    data = pd.read_csv(path)
    required = FEATURES + [TARGET]
    missing = [col for col in required if col not in data.columns]
    if missing:
        raise ValueError("Dataset is missing required columns: " + ", ".join(missing))
    data = data[required].copy()
    for col in FEATURES + [TARGET]:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data = data.dropna(subset=[TARGET])
    data[TARGET] = data[TARGET].astype(int).clip(0, 1)
    return data

def build_pipeline(estimator):
    prep = ColumnTransformer(
        transformers=[("numeric", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler())
        ]), FEATURES)],
        remainder="drop"
    )
    return Pipeline([("preprocess", prep), ("model", estimator)])

def model_definitions():
    return {
        "Logistic Regression": LogisticRegression(max_iter=1500, class_weight="balanced", random_state=42),
        "Decision Tree": DecisionTreeClassifier(max_depth=6, class_weight="balanced", random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=160, max_depth=8, class_weight="balanced", random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=100, max_depth=2, random_state=42)
    }

def train_and_compare(data):
    X = data[FEATURES]
    y = data[TARGET]
    if y.nunique() < 2:
        raise ValueError("The target column must contain both 0 (Not Placed) and 1 (Placed).")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    results = []
    trained = {}
    for name, estimator in model_definitions().items():
        pipeline = build_pipeline(estimator)
        pipeline.fit(X_train, y_train)
        pred = pipeline.predict(X_test)
        row = {
            "Model": name,
            "Accuracy": round(float(accuracy_score(y_test, pred)), 4),
            "Precision": round(float(precision_score(y_test, pred, zero_division=0)), 4),
            "Recall": round(float(recall_score(y_test, pred, zero_division=0)), 4),
            "F1-score": round(float(f1_score(y_test, pred, zero_division=0)), 4)
        }
        if hasattr(pipeline, "predict_proba") and y_test.nunique() == 2:
            row["ROC-AUC"] = round(float(roc_auc_score(y_test, pipeline.predict_proba(X_test)[:, 1])), 4)
        else:
            row["ROC-AUC"] = np.nan
        results.append(row)
        trained[name] = pipeline
    return pd.DataFrame(results), trained, {"train_rows": len(X_train), "test_rows": len(X_test)}

def predict_placement(data, profile, model_name="Random Forest"):
    results, trained, _ = train_and_compare(data)
    model = trained[model_name]
    row = pd.DataFrame([{key: profile[key] for key in FEATURES}], columns=FEATURES)
    probability = float(model.predict_proba(row)[0][1])
    prediction = int(model.predict(row)[0])
    return {
        "label": "Placed (demo)" if prediction == 1 else "Not Placed (demo)",
        "probability": probability
    }
